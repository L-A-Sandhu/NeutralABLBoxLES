#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
export_cube.py

Robust OpenFOAM exporter for volVectorField U and volScalarField p.

Key behaviors
- Works whether the run has reconstructed time folders (run/TIME/U) or only processor*/TIME/U.
- If only processor*/ exist, it automatically runs reconstructPar over the capture window.
- Automatically filters out time folders where U or p internalField is 'uniform' (e.g., the copied template ./0).
- If you request --t0 0 --t1 200 and a capture_window.json exists, it anchors that window at t_spin
  (capture start) rather than at time=0 in the run directory.

Outputs (written into the run directory)
- <out_prefix>_U.npy      : U array
- <out_prefix>_p.npy      : p array
- <out_prefix>.meta.json  : metadata including selected times

Shapes
- If Nx,Ny,Nz match the cell count: U (T, Nz, Ny, Nx, 3), p (T, Nz, Ny, Nx)
- Otherwise:                 U (T, Ncells, 3),        p (T, Ncells)
"""

import argparse
import json
import os
import re
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
from numpy.lib.format import open_memmap

NUMERIC_DIR_RE = re.compile(r"^[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$")


def _run(cmd: List[str], cwd: Path) -> None:
    p = subprocess.run(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"Command failed ({p.returncode}): {' '.join(cmd)}\n{p.stdout}")


def _list_numeric_dirs(parent: Path) -> List[float]:
    out = []
    if not parent.exists():
        return out
    for p in parent.iterdir():
        if p.is_dir() and NUMERIC_DIR_RE.match(p.name):
            try:
                out.append(float(p.name))
            except ValueError:
                pass
    return sorted(out)


def _processor_dirs(run_dir: Path) -> List[Path]:
    return sorted([p for p in run_dir.iterdir() if p.is_dir() and p.name.startswith("processor")])


def _read_capture_window(run_dir: Path) -> Optional[Tuple[float, float]]:
    jpath = run_dir / "capture_window.json"
    if not jpath.exists():
        return None
    try:
        j = json.loads(jpath.read_text())
        t_spin = float(j.get("t_spin"))
        end_time = float(j.get("end_time"))
        return t_spin, end_time
    except Exception:
        return None


def _internal_field_kind(path: Path) -> Tuple[str, str]:
    """
    Returns (format, kind) where:
      format in {"ascii","binary","unknown"}
      kind   in {"uniform","nonuniform","missing"}
    """
    if not path.exists():
        return "unknown", "missing"

    fmt = "unknown"
    kind = "missing"
    try:
        with path.open("r", errors="ignore") as f:
            for _ in range(4000):  # bound scan
                line = f.readline()
                if not line:
                    break
                s = line.strip()
                if s.startswith("format"):
                    fmt = "binary" if "binary" in s else "ascii"
                if s.startswith("internalField"):
                    if "nonuniform" in s:
                        kind = "nonuniform"
                    elif "uniform" in s:
                        kind = "uniform"
                    else:
                        kind = "missing"
                    break
    except Exception:
        return "unknown", "missing"

    return fmt, kind


def _ensure_reconstructed(run_dir: Path, tmin: float, tmax: float) -> None:
    # If we already have reconstructed nonuniform fields, do nothing.
    times = _list_numeric_dirs(run_dir)
    for t in times:
        up = run_dir / f"{t:g}" / "U"
        pp = run_dir / f"{t:g}" / "p"
        _, uk = _internal_field_kind(up)
        _, pk = _internal_field_kind(pp)
        if uk == "nonuniform" and pk == "nonuniform":
            return

    if not _processor_dirs(run_dir):
        return

    tr = f"{tmin}:{tmax}"
    print(f"[export] Reconstructing fields with reconstructPar -time '{tr}' ...")
    _run(["reconstructPar", "-time", tr], cwd=run_dir)


def _read_internal_field_ascii(path: Path, kind: str, dtype: np.dtype) -> np.ndarray:
    """
    Parse OpenFOAM ascii internalField:
      - scalar: nonuniform List<scalar>
      - vector: nonuniform List<vector>
    """
    fmt, k = _internal_field_kind(path)
    if k != "nonuniform":
        raise RuntimeError(f"{path} internalField is not nonuniform (found {k}).")
    if fmt == "binary":
        raise RuntimeError(
            f"{path} is binary. Set writeFormat ascii in your capture controlDict, rerun capture, then export."
        )

    with path.open("r", errors="ignore") as f:
        # Seek to 'internalField'
        for line in f:
            s = line.strip()
            if s.startswith("internalField") and "nonuniform" in s:
                break

        # Next non-empty token should be N (entry count)
        while True:
            line = next(f)
            s = line.strip()
            if s and not s.startswith("//"):
                break
        n = int(s.split()[0])

        # Advance until '('
        while True:
            line = next(f)
            if "(" in line:
                break

        if kind == "vector":
            out = np.empty((n, 3), dtype=dtype)
        else:
            out = np.empty((n,), dtype=dtype)

        i = 0
        for line in f:
            s = line.strip()
            if not s or s.startswith("//"):
                continue
            if s.startswith(")"):
                break
            s = s.split("//", 1)[0].strip()
            if not s:
                continue
            s = s.replace("(", " ").replace(")", " ")
            arr = np.fromstring(s, sep=" ", dtype=float)

            if kind == "scalar":
                m = arr.size
                out[i:i + m] = arr.astype(dtype, copy=False)
                i += m
            else:
                if arr.size % 3 != 0:
                    raise RuntimeError(f"Bad vector line in {path}: {line.strip()}")
                m = arr.size // 3
                out[i:i + m, :] = arr.reshape(m, 3).astype(dtype, copy=False)
                i += m

        if i != n:
            raise RuntimeError(f"Parsed {i} entries but header says {n} in {path}")
        return out


def _infer_dims(ncells: int, Nx: int, Ny: int, Nz: int) -> Optional[Tuple[int, int, int]]:
    return (Nx, Ny, Nz) if (Nx > 0 and Ny > 0 and Nz > 0 and Nx * Ny * Nz == ncells) else None


def _available_nonuniform_times(run_dir: Path, U_name: str, p_name: str) -> List[float]:
    times = _list_numeric_dirs(run_dir)
    good = []
    for t in times:
        up = run_dir / f"{t:g}" / U_name
        pp = run_dir / f"{t:g}" / p_name
        _, uk = _internal_field_kind(up)
        _, pk = _internal_field_kind(pp)
        if uk == "nonuniform" and pk == "nonuniform":
            good.append(t)
    return sorted(good)


def _select_times(avail: List[float], t0: float, t1: float, dt: float) -> List[float]:
    if not avail:
        return []

    # Use capture_window.json anchor logic implicitly:
    # If user gave t0=0 and there is a large gap between 0 and first nonuniform time,
    # we treat [t0,t1] as relative to the first nonuniform time (capture start).
    anchor = avail[0]
    if abs(t0) < 1e-12:
        abs_t0 = anchor + t0
        abs_t1 = anchor + t1
        print(f"[export] Anchoring t0/t1 at first nonuniform time {anchor:.6f}: range=[{abs_t0:.6f},{abs_t1:.6f}]")
    else:
        abs_t0, abs_t1 = t0, t1

    if abs_t1 < abs_t0:
        abs_t0, abs_t1 = abs_t1, abs_t0

    # Build target times on a regular grid starting at the first available >= abs_t0
    start_candidates = [t for t in avail if t >= abs_t0 - 1e-9]
    if not start_candidates:
        return []
    t_start = start_candidates[0]

    targets = []
    k = 0
    while True:
        tt = t_start + k * dt
        if tt > abs_t1 + 1e-9:
            break
        targets.append(tt)
        k += 1

    # Snap targets to nearest available time within tolerance
    tol = max(1e-3, 0.05 * dt)
    chosen = []
    ai = 0
    for tt in targets:
        while ai + 1 < len(avail) and avail[ai + 1] <= tt:
            ai += 1
        best = avail[ai]
        if ai + 1 < len(avail) and abs(avail[ai + 1] - tt) < abs(best - tt):
            best = avail[ai + 1]
        if abs(best - tt) <= tol:
            chosen.append(best)

    return sorted(set(chosen))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True, help="Run directory (contains processor*/ or reconstructed time folders)")
    ap.add_argument("--Nx", type=int, default=180)
    ap.add_argument("--Ny", type=int, default=80)
    ap.add_argument("--Nz", type=int, default=80)
    ap.add_argument("--U_name", default="U")
    ap.add_argument("--p_name", default="p")
    ap.add_argument("--dt", type=float, default=0.5)
    ap.add_argument("--t0", type=float, default=0.0)
    ap.add_argument("--t1", type=float, default=200.0)
    ap.add_argument("--dtype", choices=["float32", "float64"], default="float32")
    ap.add_argument("--out-prefix", dest="out_prefix", default="U_all")
    args = ap.parse_args()

    run_dir = Path(args.run).resolve()
    if not run_dir.exists():
        raise SystemExit(f"Run directory not found: {run_dir}")

    dtype = np.float32 if args.dtype == "float32" else np.float64

    # If no reconstructed nonuniform times but processor*/ exist, reconstruct over capture window.
    cw = _read_capture_window(run_dir)
    if cw is not None:
        t_spin, end_time = cw
        _ensure_reconstructed(run_dir, t_spin, end_time)
    else:
        # fallback: if processor*/ exist, reconstruct full processor0 range
        procs = _processor_dirs(run_dir)
        if procs:
            p0 = procs[0]
            pt = _list_numeric_dirs(p0)
            if pt:
                _ensure_reconstructed(run_dir, pt[0], pt[-1])

    avail = _available_nonuniform_times(run_dir, args.U_name, args.p_name)
    if not avail:
        # Helpful diagnostics
        all_times = _list_numeric_dirs(run_dir)
        raise SystemExit(
            "No reconstructed time folders with nonuniform U and p found.\n"
            f"Found time dirs: {all_times[:10]} ... {all_times[-10:]}\n"
            "If you ran in parallel, ensure reconstructPar is available and your fields are written in ASCII."
        )

    sel = _select_times(avail, args.t0, args.t1, args.dt)
    if not sel:
        raise SystemExit(
            "No times selected after filtering to nonuniform fields.\n"
            f"First 10 available nonuniform times: {avail[:10]}\n"
            f"Last 10 available nonuniform times: {avail[-10:]}\n"
            "Tip: try explicit absolute capture bounds, e.g. --t0 33 --t1 233."
        )

    print(f"[export] Selected {len(sel)} times: {sel[0]:.6f} ... {sel[-1]:.6f}")

    # Read first time to get cell count
    t_first = sel[0]
    U0 = _read_internal_field_ascii(run_dir / f"{t_first:g}" / args.U_name, "vector", dtype)
    p0 = _read_internal_field_ascii(run_dir / f"{t_first:g}" / args.p_name, "scalar", dtype)
    ncells = U0.shape[0]

    dims = _infer_dims(ncells, args.Nx, args.Ny, args.Nz)
    T = len(sel)

    out_u = run_dir / f"{args.out_prefix}_U.npy"
    out_p = run_dir / f"{args.out_prefix}_p.npy"
    out_meta = run_dir / f"{args.out_prefix}.meta.json"

    if dims is not None:
        Nx, Ny, Nz = dims
        U_shape = (T, Nz, Ny, Nx, 3)
        p_shape = (T, Nz, Ny, Nx)
        reshape = True
    else:
        U_shape = (T, ncells, 3)
        p_shape = (T, ncells)
        reshape = False

    print(f"[export] Writing: {out_u.name} and {out_p.name}")
    U_mm = open_memmap(out_u, mode="w+", dtype=dtype, shape=U_shape)
    p_mm = open_memmap(out_p, mode="w+", dtype=dtype, shape=p_shape)

    def place(ti: int, Uflat: np.ndarray, pflat: np.ndarray):
        if reshape:
            U_mm[ti, ...] = Uflat.reshape((Nz, Ny, Nx, 3), order="C")
            p_mm[ti, ...] = pflat.reshape((Nz, Ny, Nx), order="C")
        else:
            U_mm[ti, ...] = Uflat
            p_mm[ti, ...] = pflat

    place(0, U0, p0)

    for ti, t in enumerate(sel[1:], start=1):
        U = _read_internal_field_ascii(run_dir / f"{t:g}" / args.U_name, "vector", dtype)
        p = _read_internal_field_ascii(run_dir / f"{t:g}" / args.p_name, "scalar", dtype)
        if U.shape[0] != ncells or p.shape[0] != ncells:
            raise RuntimeError(f"Cell-count mismatch at time {t:g}")
        place(ti, U, p)
        if ti % 25 == 0 or ti == T - 1:
            print(f"[export] {ti+1}/{T}")

    del U_mm
    del p_mm

    meta = {
        "run_dir": str(run_dir),
        "times": sel,
        "dt_target": args.dt,
        "t0_arg": args.t0,
        "t1_arg": args.t1,
        "fields": {"U": args.U_name, "p": args.p_name},
        "ncells": int(ncells),
        "dims": {"Nx": args.Nx, "Ny": args.Ny, "Nz": args.Nz} if dims is not None else None,
        "shapes": {"U": list(U_shape), "p": list(p_shape)},
        "dtype": args.dtype,
        "capture_window": {"t_spin": cw[0], "end_time": cw[1]} if cw is not None else None,
    }
    out_meta.write_text(json.dumps(meta, indent=2))

    print("[export] DONE")
    print(f"[export] U shape = {U_shape}")
    print(f"[export] p shape = {p_shape}")


if __name__ == "__main__":
    main()
